echo on
xcopy ipss.exe  /home/eduardo\.ipss
echo " "
echo "IPSS is now installed, add /home/eduardo\.ipss\ to your PATH variable to run."
pause
