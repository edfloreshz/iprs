Remove-Item Path /home/eduardo\.ipss\ipss.exe -Recurse
echo "IPSS is now uninstalled."
pause
